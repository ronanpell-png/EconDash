DESIGN

OVERVIEW

EconDash  is a Python web app built largely using Flask. It provides an interactive dashboard with important US macroeconomic indicators. Using the FRED API for live data retrieval, EconDash can access a user-friendly interface to gain a sense of the US's macroeconomic condition. Users can view data and charts for indicators like GDP, CPI, unemployment, federal funds rate, the S and P 500, and tje yield curve. The app caches API responses, dynamically calculates trends and changes, and allows for CSV download of data.

DATA FETCHING & CACHING

I utilized the Python requests library to fetch data from the FRED API. I chose to then convert that data into Pandas DataFrames to process it and perform calculations (since Pandas allows for easy manipulation of dates and values). So that I wouldn't continuously and needlessly call the FRED API, I implemented hourly caching. I used the Python deorator functools.lru_cache to do this, including the series ID and current hour for each. Thus, the page is able to load much faster.

ROUTING & PAGES
Within my app.py, I gave each economic indicator its own route (ex. /gdp, /cpi, /unemployment). Then, to avoid creating many html pages, I used indicator.html as a template for GDP, CPI, Fed Funds, Unemployment, and S&P 500. Since Yield Curve, Calendar, and Compare each have specialized formats, I created a separate html for each. Similarly, Dashboard needed its own html template to display data from all of the other indicators.

TEMPLATES
Each of the templates receives pre-processed data from Flask routes and displays it in data tables and Plotly charts. I wanted the amount of data to be modular, so I added buttons to increase and decrease number of data points. I made sure that these buttons would also affect the graphs of each. I then implemented features like zooming, panning, and CSV download using Plotly and JavaScript controls. Plotly proved to a perfect candidate in creating the interactive graphs I'd envisioned. It also came in especially handy when I used Plotly's z-score, index to 100, and percent change functions for comparison of indicators.

TREASURY YIELD
I chose to calculate the 2-year/10-year spread to check for inversion. That tells users whether the shape of the yield curve is normal, flat, or inverted.
