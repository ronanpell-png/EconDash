Thank you for taking the time to review my project!

Video link: https://youtu.be/kbl8Qe3tQDQ

OVERVIEW

My project provides a real-time dashboard of key US economic data. By utilizing the FRED API, I am able to use this data directly from the Federal Reserve. Then, using Plotly, I was able to create interactive graphs to better display data. I have also implemented a downloadable CSV file with the data for each, customized for the data size you want.

EconDash should be relatively self-explanatory, on the GDP, Fed Funds, CPI, and S&P 500 pages, the 10 most recent data points are plotted on a graph and listed in a data table. The graphs are interactive, so feel free to zoom, pan, scale, and download to your hearts content (this functionality is all in the top right of the graph). Also, to customize your data, feel free to press "See 10 More" or "See All" to see more data. To reset the amount of data, you can press the "Most Recent 10." To decrease data, press "See 10 Less." You can also download a CSV of your given data by pressing the "Download CSV" button.

The Compare page is a bit different. No real understanding is needed, but feel free to play with the check boxes to see how the chart changes.


USING THE APP

In order to access EconDash, please follow the following instructions:

1. Install required packages and dependencies.
In the terminal, run the following commands:

python3 -m pip install --upgrade pip

AND

pip install Flask pandas requests plotly

2. My FRED API is hardcoded for ease of access.
However, if that that does not work for some reason, run the following command in the terminal:

export FRED_API_KEY = "4bfa7711b674526e81033245cc15c439"

3. Finally, you may run EconDash by running the following command in the terminal:

flask run

